import React from 'react'
import AppLayout from '../components/style/AppLayout'
const  Home =()=> {
  return (
    <div className='w-4/6 border-2 h-[93vh] flex justify-center items-center text-7xl'>
      Home
    </div>
  )
}

export default AppLayout()(Home);