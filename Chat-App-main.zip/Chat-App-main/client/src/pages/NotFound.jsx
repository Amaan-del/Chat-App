import React from 'react'

function NotFound() {
  return (
    <div>Sorry Route Not Found</div>
  )
}

export default NotFound